package com.lezijie;

import cn.hutool.crypto.digest.DigestUtil;
import com.lezijie.note.dao.BaseDao;
import com.lezijie.note.dao.UserDao;
import com.lezijie.note.po.User;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;


public class TestUser {
    @Test
    public void tsetQueruUser(){
        UserDao userDao=new UserDao();
        User user=userDao.queryUserByName2("admin");
        System.out.println(user.getUpwd());
        String userPwd="e10adc3949ba59abbe56e057f20f883e";
        userPwd = DigestUtil.md5Hex(userPwd);
        System.out.println("Encrypted Password: " + userPwd);
        System.out.println("Password from DB: " + user.getUpwd());
    }

    @Test
    public void testAdd(){
        String sql="insert into tb_user(uname,upwd,nick,head,mood) values(?,?,?,?,?)";
        List<Object> params=new ArrayList<>();
        params.add("lisi");
        params.add("e10adc3949ba59abbe56e057f20f883e");
        params.add("lisi");
        params.add("404.jpg");
        params.add("Hello");
        int row= BaseDao.executeUpdate(sql,params);
        System.out.println(row);
    }
}
