package com.lezijie.note.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NoteVo {
    private String groupName;
    private long noteCount;
    private Integer typeId;

}
