package com.lezijie.note.service;

import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.digest.DigestUtil;
import com.lezijie.note.dao.UserDao;
import com.lezijie.note.po.User;
import com.lezijie.note.vo.ResultInfo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;


public class UserService {
    private UserDao userDao=new UserDao();
    public ResultInfo<User> userLogin(String userName,String userPwd){
        ResultInfo<User> resultInfo=new ResultInfo<>();
        // 数据回显：当登录实现时，将登录信息返回给页面显示
        User u = new User();
        u.setUname(userName);
        u.setUpwd(userPwd);
        // 设置到resultInfo对象中
        resultInfo.setResult(u);
        if(StrUtil.isBlank(userName)||StrUtil.isBlank(userPwd)){
            resultInfo.setCode(0);
            resultInfo.setMsg("用户姓名或密码不能为空");
            return resultInfo;
        }


        User user=userDao.queryUserByName2(userName);


        if(user==null){
            resultInfo.setCode(0);
            resultInfo.setMsg("用户名不存在");
            return resultInfo;
        }

//        userPwd= DigestUtil.md5Hex(userPwd);
        if(!userPwd.equals(user.getUpwd())){
            resultInfo.setCode(0);
            resultInfo.setMsg("密码不正确!");
            return resultInfo;
        }

        resultInfo.setCode(1);
        resultInfo.setResult(user);
        return resultInfo;
    }

    public Integer checkNick(String nick,Integer userId){
        //判断是否为空
        if (StrUtil.isBlank(nick)){
            return 0;
        }
        //调用Dao层，通过用户ID和昵称查询用户对象
        User user=userDao.queryUserByNickAndUserId(nick,userId);
        if (user!=null){
            return 0;
        }
        return 1;
    }

    public ResultInfo<User> updateUser(HttpServletRequest request) {
        ResultInfo<User> resultInfo=new ResultInfo<>();
        String nick=request.getParameter("nick");
        String mood=request.getParameter("mood");

        if (StrUtil.isBlank(nick)){
            resultInfo.setCode(0);
            resultInfo.setMsg("用户名称不能为空");
        }
        //从session作用域中获取用户对象
        User user=(User)request.getSession().getAttribute("user");
        //设置修改的昵称和头像
        user.setNick(nick);
        user.setMood(mood);
        //实现上传文件
        try{
            Part part=request.getPart("img");
            String header=part.getHeader("Content-Disposition");
            //获取具体的请求头对应的值
            String str=header.substring(header.lastIndexOf("=")+2);
            String fileName=str.substring(0,str.length()-1);
            if (!StrUtil.isBlank(fileName)){
                user.setHead(fileName);
                String filepath=request.getServletContext().getRealPath("/WEB-INF/upload");
                //上传文件到指定目录
                part.write(filepath+"/"+fileName);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        int row=userDao.updateUser(user);
        if(row>0){
            resultInfo.setCode(1);
            //更新session中的用户对象
            request.getSession().setAttribute("user",user);
        }else {
            resultInfo.setCode(0);
            resultInfo.setMsg("更新失败！");
        }
        return resultInfo;
    }
}
