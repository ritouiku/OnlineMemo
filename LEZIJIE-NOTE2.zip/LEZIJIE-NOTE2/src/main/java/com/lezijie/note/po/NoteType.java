package com.lezijie.note.po;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NoteType {
    private Integer typeId;
    private String typeName;
    private Integer userId;

}
