package com.lezijie.note.dao;

import com.lezijie.note.util.DBUtil;
import com.mysql.cj.x.protobuf.MysqlxExpr;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

/*
* 基础JDBC
* a更新操作
* 查询操作
* 1.查询一个字段
* 2.查询集合
* 3.查询某个对象
* */

public class BaseDao {
    public static int executeUpdate(String sql, List<Object> params){
        int row=0;
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        try {
            //得到数据库并预编译
            connection=DBUtil.getConnection();
            preparedStatement=connection.prepareStatement(sql);
            //如果有参数则设置参数
            if(params!=null&&params.size()>0) {
                for(int i=0;i<params.size();i++){
                    preparedStatement.setObject(i+1,params.get(i));
                }
            }
            row=preparedStatement.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            //关闭资源
            DBUtil.close(null,preparedStatement,connection);
        }
        return row;
    }

    public static Object findSingleValue(String sql,List<Object> params){
        Object object=null;
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        try {
            //获取链接
            connection=DBUtil.getConnection();
            preparedStatement=connection.prepareStatement(sql);
            //如果有参数则设置参数
            if(params!=null&&params.size()>0) {
                for(int i=0;i<params.size();i++){
                    preparedStatement.setObject(i+1,params.get(i));
                }
            }
            //执行查询返回结果集
            resultSet=preparedStatement.executeQuery();
            if(resultSet.next()){
                object=resultSet.getObject(1);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            DBUtil.close(resultSet,preparedStatement,connection);
        }

        return object;
    }

    public static List queryRows(String sql,List<Object> params,Class cls){
        List list=new ArrayList();
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        try {
            //得到数据库链接
            connection=DBUtil.getConnection();

            preparedStatement=connection.prepareStatement(sql);

            if(params!=null&&params.size()>0) {
                for(int i=0;i<params.size();i++){
                    preparedStatement.setObject(i+1,params.get(i));
                }
            }
            //执行查询返回结果集
            resultSet=preparedStatement.executeQuery();
            //得到结果集的元数据对象（查询到的字段数量以及查寻了哪些字段）
            ResultSetMetaData resultSetMetaData=resultSet.getMetaData();
            int fieldNum=resultSetMetaData.getColumnCount();
            //单端并分析结果集
            while (resultSet.next()){
                Object object=cls.newInstance();
                //查询遍历的字段数量，得到数据库中每一个列名
                //getColumnLabel(i)获取列名或别名
                for(int i=1;i<=fieldNum;i++){
                    String columnName=resultSetMetaData.getColumnLabel(i);
                    //通过反射，使得列名得到对应的field对象
                    Field field=cls.getDeclaredField(columnName);
                    String setMethod="set"+columnName.substring(0,1).toUpperCase()+columnName.substring(1);
                    //通过反射，将set方法字符出啊反射成类中对应的set方法
                    Method method=cls.getDeclaredMethod(setMethod,field.getType());
                    //得到查询每一个字段对应的值
                    Object value=resultSet.getObject(columnName);
                    //通过invoke方法调用set方法
                    method.invoke(object,value);
                }
                //将javabean设置到集合中
                list.add(object);
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        return list;
    }

    public static Object queryRow(String sql,List<Object> params,Class cls){
        List list=queryRows(sql,params,cls);
        Object object=null;
        //如果集合不为空
        if(list!=null&&list.size()>0){
            object=list.get(0);
        }
        return object;
    }
}

