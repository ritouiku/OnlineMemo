package com.lezijie.note.po;

public class User {
    private Integer userId;
    private String uname;
    private String upwd;
    private String nick;
    private String head;
    private String mood;

    public Integer getUserId() {
        return userId;
    }

    public String getUname() {
        return uname;
    }

    public String getUpwd() {
        return upwd;
    }

    public String getNick() {
        return nick;
    }

    public String getHead() {
        return head;
    }

    public String getMood() {
        return mood;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public void setUpwd(String upwd) {
        this.upwd = upwd;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public void setMood(String mood) {
        this.mood = mood;
    }
}
