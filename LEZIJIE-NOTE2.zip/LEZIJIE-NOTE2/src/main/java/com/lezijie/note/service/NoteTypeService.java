package com.lezijie.note.service;

import cn.hutool.core.util.StrUtil;
import com.lezijie.note.dao.NoteTypeDao;
import com.lezijie.note.po.NoteType;
import com.lezijie.note.vo.ResultInfo;

import java.util.List;

public class NoteTypeService {
    private NoteTypeDao typeDao=new NoteTypeDao();

    public List<NoteType> findTypeList(Integer userId){
        List<NoteType> typeList=typeDao.findTypeListByUserId(userId);
        return typeList;
    }

    public ResultInfo<NoteType> deleteType(String typeId) {
        ResultInfo<NoteType> resultInfo=new ResultInfo<>();
        //判断参数是否为空
        if(StrUtil.isBlank(typeId)){
            resultInfo.setCode(0);
            resultInfo.setMsg("系统异常，请重试！");
            return resultInfo;
        }
        //调用Dao层，通过类型ID查询云记记录的数量
        long noteCount=typeDao.findNoteCountByTypeId(typeId);
        if (noteCount>0){
            resultInfo.setCode(0);
            resultInfo.setMsg("该类型存在子记录不可删除！！");
            return resultInfo;
        }

        //如果不存在子记录，调用Dao层的更新方法，通过类型ID删除指定的类型记录，返回受影响的行数
        int row=typeDao.deleteTypeById(typeId);
        //判断受影响的行数是否大于0
        if(row>0){
            resultInfo.setCode(1);
        }else {
            resultInfo.setCode(0);
            resultInfo.setMsg("删除失败！");
        }
        return resultInfo;
    }

    public ResultInfo<Integer> addOrUpdate(String typeName, Integer userId, String typeId) {
        ResultInfo<Integer> resultInfo=new ResultInfo<>();
        //判断参数是否为空
        if(StrUtil.isBlank(typeName)){
            resultInfo.setCode(0);
            resultInfo.setMsg("类型名称不能为空");
            return resultInfo;
        }
        //调用Dao层查询当前登录用户下，类型名称是否唯一，返回0或1
        Integer code=typeDao.checkTypeName(typeName,userId,typeId);
        //如果不可用，code=0，msg=xxx返回ResultInfo对象
        if(code==0){
            resultInfo.setCode(0);
            resultInfo.setMsg("类型名称已存在，请重新输入");
            return resultInfo;
        }

        Integer key=null;
        //判断是否为空
        if(StrUtil.isBlank(typeId)){
            //如果为空，调用Dao层添加方法，返回主键
            key=typeDao.addType(typeName,userId);
        }else {
            //如果不为空，调用Dao层的修改方法，返回受影响的行数
            key=typeDao.updateType(typeName,typeId);
        }

        if (key>0){
            resultInfo.setCode(1);
            resultInfo.setResult(key);
        }else {
            resultInfo.setCode(0);
            resultInfo.setMsg("更新失败！");
        }

        return resultInfo;

    }
}
