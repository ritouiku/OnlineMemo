package com.lezijie.note.web;

import com.lezijie.note.po.User;
import com.lezijie.note.service.UserService;
import com.lezijie.note.vo.ResultInfo;
import org.apache.commons.io.FileUtils;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;

@WebServlet("/user")
@MultipartConfig
public class UserServlet extends HttpServlet {
    private UserService userService=new UserService();
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String actionName=request.getParameter("actionName");
        //判断用户行为
        if("login".equals(actionName)){
            userLogin(request,response);
        }else if ("logout".equals(actionName)){
            //用户退出
            userLogOut(request,response);
        }else if("userCenter".equals(actionName)){
            //进入个人中心
            userCenter(request,response);
        }else if("userHead".equals(actionName)){
            //加载头像
            userHead(request,response);
        }else if ("checkNick".equals(actionName)){
            //验证昵称的唯一性
            checkNick(request,response);
        }else if ("updateUser".equals(actionName)){
            //修改用户信息
            updateUser(request,response);
        }
    }

    private void updateUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //调用Service层的方法，传递request对象作为参数，返回resultInfo
        ResultInfo<User> resultInfo=userService.updateUser(request);
        request.setAttribute("resultInfo",resultInfo);
        //请求转发到个人页面
        request.getRequestDispatcher("user?actionName=userCenter").forward(request,response);
    }

    private void checkNick(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String nick=request.getParameter("nick");
        //从session作用域获取用户对象
        User user=(User) request.getSession().getAttribute("user");
        //调用Service层的方法
        Integer code=userService.checkNick(nick,user.getUserId());
        response.getWriter().write(code+"");
        //关闭资源
        response.getWriter().close();
    }

    private void userHead(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String head=request.getParameter("imageName");
        //得到真实路径
        String realPath =request.getServletContext().getRealPath("/WEB-INF/upload/");
        //通过图片的完整路径得到file对象
        File file=new File(realPath+"/"+head);
        //通过截取得到图片后缀
        String pic=head.substring(head.lastIndexOf(".")+1);
        if ("PNG".equalsIgnoreCase(pic)){
            response.setContentType("image/png");
        }else if("JPN".equalsIgnoreCase(pic)||"JPEG".equalsIgnoreCase(pic)){
            response.setContentType("image/jpeg");
        }else if ("GIF".equalsIgnoreCase(pic)){
            response.setContentType("image/gif");
        }
        FileUtils.copyFile(file,response.getOutputStream());
    }

    private void userCenter(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.设置首页动态包含的页面值
        request.setAttribute("changePage","user/info.jsp");
        //请求转发到index
        request.getRequestDispatcher("index.jsp").forward(request,response);
    }

    private void userLogOut(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // 1. 销毁Session对象
        request.getSession().invalidate();
        // 2. 删除Cookie对象
        Cookie cookie = new Cookie("user", null);
        cookie.setMaxAge(0); // 设置0，表示删除cookie
        response.addCookie(cookie);
        // 3. 重定向跳转到登录页面
        response.sendRedirect("login.jsp");
    }

    private  void userLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userName=request.getParameter("userName");
        String userPwd=request.getParameter("userPwd");

        ResultInfo<User> resultInfo=userService.userLogin(userName,userPwd);

        if(resultInfo.getCode()==1){
            request.getSession().setAttribute("user",resultInfo.getResult());
            String rem=request.getParameter("rem");
            if("1".equals(rem)){
                Cookie cookie=new Cookie("user",userName+"-"+userPwd);
                cookie.setMaxAge(3*24*60*60);
                response.addCookie(cookie);
            }else {
                Cookie cookie=new Cookie("user",null);
                cookie.setMaxAge(0);
                response.addCookie(cookie);
            }
            response.sendRedirect("index.jsp");
        }else{//失败
            request.setAttribute("resultInfo",resultInfo);
            request.getRequestDispatcher("login.jsp").forward(request,response);
        }
    }
}
