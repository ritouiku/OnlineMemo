package com.lezijie.note.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

public class DBUtil {

    private static Properties properties=new Properties();

    static {
        try {
            InputStream inputStream=DBUtil.class.getClassLoader().getResourceAsStream("db.properties");
            properties.load(inputStream);
            Class.forName(properties.getProperty("jdbcName"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection(){
        Connection connection=null;
        //获取数据库相关信息
        String dburl=properties.getProperty("dbUrl");
        String dbName=properties.getProperty("dbName");
        String dbPwd=properties.getProperty("dbPwd");

        try {
            connection= DriverManager.getConnection(dburl,dbName,dbPwd);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return connection;
    }
    public static  void close(ResultSet resultSet,
                              PreparedStatement preparedStatement,
                              Connection connection){

            try {
                if(resultSet!=null) {
                    resultSet.close();
                }
                if(preparedStatement!=null) {
                    preparedStatement.close();
                }
                if(connection!=null) {
                    connection.close();
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
}
